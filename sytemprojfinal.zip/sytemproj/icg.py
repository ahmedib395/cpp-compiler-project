import sys
import json

class TACGenerator:
    def __init__(self, ast):
        self.ast = ast
        self.code = []
        self.temp_count = 0
        self.label_count = 0
        self.loop_labels = [] # Stack of (start_label, end_label)

    def new_temp(self):
        self.temp_count += 1
        return f"t{self.temp_count}"

    def new_label(self):
        self.label_count += 1
        return f"L{self.label_count}"

    def generate(self):
        self.visit(self.ast)
        return self.code

    def emit(self, instruction):
        self.code.append(instruction)

    def visit(self, node):
        if not node: return None
        node_type = node.get("type")

        if node_type == "Program":
            for stmt in node.get("body", []):
                self.visit(stmt)
        elif node_type == "Declaration":
            var_id = node.get("id")
            if node.get("value"):
                val = self.visit(node.get("value"))
                self.emit(f"{var_id} = {val}")
        elif node_type == "Assignment":
            var_id = node.get("id")
            val = self.visit(node.get("value"))
            self.emit(f"{var_id} = {val}")
        elif node_type == "WhileLoop":
            start_label = self.new_label()
            end_label = self.new_label()
            self.emit(f"{start_label}:")
            
            condition_result = self.visit(node.get("condition"))
            self.emit(f"ifFalse {condition_result} goto {end_label}")
            
            self.loop_labels.append((start_label, end_label))
            for stmt in node.get("body", []):
                self.visit(stmt)
            self.loop_labels.pop()
            
            self.emit(f"goto {start_label}")
            self.emit(f"{end_label}:")
            
        elif node_type == "IfStatement":
            condition_result = self.visit(node.get("condition"))
            else_label = self.new_label()
            end_label = self.new_label()
            
            self.emit(f"ifFalse {condition_result} goto {else_label}")
            
            for stmt in node.get("body", []):
                self.visit(stmt)
            self.emit(f"goto {end_label}")
            
            self.emit(f"{else_label}:")
            if node.get("else_body"):
                for stmt in node.get("else_body"):
                    self.visit(stmt)
            self.emit(f"{end_label}:")
            
        elif node_type == "Condition":
            left = self.visit(node.get("left"))
            right = self.visit(node.get("right"))
            op = node.get("operator")
            temp = self.new_temp()
            self.emit(f"{temp} = {left} {op} {right}")
            return temp
            
        elif node_type == "BinaryExpression":
            left = self.visit(node.get("left"))
            right = self.visit(node.get("right"))
            op = node.get("operator")
            temp = self.new_temp()
            self.emit(f"{temp} = {left} {op} {right}")
            return temp
            
        elif node_type == "BreakStatement":
            if self.loop_labels:
                _, end_label = self.loop_labels[-1]
                self.emit(f"goto {end_label}")
        elif node_type == "ContinueStatement":
            if self.loop_labels:
                start_label, _ = self.loop_labels[-1]
                self.emit(f"goto {start_label}")
        elif node_type == "Identifier":
            return node.get("value")
        elif node_type == "Number":
            return node.get("value")
        return None

class TACOptimizer:
    def __init__(self, code):
        self.code = code
        self.optimized_code = []

    def is_number(self, s):
        try:
            float(s)
            return True
        except ValueError:
            return False

    def evaluate(self, op, left, right):
        if op == '+': return left + right
        if op == '-': return left - right
        if op == '*': return left * right
        if op == '/': return left / right if right != 0 else "DIV_BY_ZERO"
        if op == '<': return 1 if left < right else 0
        if op == '>': return 1 if left > right else 0
        if op == '<=': return 1 if left <= right else 0
        if op == '>=': return 1 if left >= right else 0
        if op == '==': return 1 if left == right else 0
        if op == '!=': return 1 if left != right else 0
        return None

    def optimize(self):
        constants = {} # map var -> value
        
        for instr in self.code:
            parts = instr.split()
            
            if not parts:
                continue

            # Label
            if instr.endswith(":"):
                self.optimized_code.append(instr)
                constants.clear() # clear constants on control flow merge
                continue
                
            # goto
            if instr.startswith("goto"):
                self.optimized_code.append(instr)
                constants.clear()
                continue
                
            # ifFalse x goto L
            if instr.startswith("ifFalse"):
                cond = parts[1]
                if cond in constants:
                    val = constants[cond]
                    if val == 0 or val == 0.0:
                        # condition is false, jump directly
                        self.optimized_code.append(f"goto {parts[3]}")
                    else:
                        # condition is true, don't jump, eliminate instruction entirely
                        pass
                else:
                    self.optimized_code.append(instr)
                constants.clear()
                continue
                
            # assignment: x = y op z OR x = y
            if "=" in parts:
                target = parts[0]
                
                if len(parts) == 3: # x = y
                    val = parts[2]
                    if val in constants:
                        val = constants[val]
                    
                    self.optimized_code.append(f"{target} = {val}")
                    
                    if self.is_number(str(val)):
                        val_num = float(val) if '.' in str(val) else int(val)
                        constants[target] = val_num
                    else:
                        if target in constants:
                            del constants[target]
                
                elif len(parts) == 5: # x = y op z
                    left = parts[2]
                    op = parts[3]
                    right = parts[4]
                    
                    if left in constants: left = constants[left]
                    if right in constants: right = constants[right]
                    
                    if self.is_number(str(left)) and self.is_number(str(right)):
                        l_val = float(left) if '.' in str(left) else int(left)
                        r_val = float(right) if '.' in str(right) else int(right)
                        
                        res = self.evaluate(op, l_val, r_val)
                        if res is not None and res != "DIV_BY_ZERO":
                            # It's an int if float equals int
                            if isinstance(res, float) and res.is_integer():
                                res = int(res)
                            self.optimized_code.append(f"{target} = {res}")
                            constants[target] = res
                        else:
                            self.optimized_code.append(f"{target} = {left} {op} {right}")
                            if target in constants: del constants[target]
                    else:
                        self.optimized_code.append(f"{target} = {left} {op} {right}")
                        if target in constants: del constants[target]
                else:
                    self.optimized_code.append(instr)
                    if target in constants: del constants[target]

        return self.optimized_code

if __name__ == "__main__":
    input_file = "ast_output.json"
    if len(sys.argv) > 1:
        input_file = sys.argv[1]

    try:
        with open(input_file, 'r') as f:
            ast = json.load(f)
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
        sys.exit(1)

    # 1. Generate TAC
    tac_gen = TACGenerator(ast)
    raw_tac = tac_gen.generate()
    
    with open("tac_unoptimized.txt", "w") as f:
        for instr in raw_tac:
            f.write(instr + "\n")
            
    # 2. Optimize TAC
    optimizer = TACOptimizer(raw_tac)
    opt_tac = optimizer.optimize()
    
    with open("tac_optimized.txt", "w") as f:
        for instr in opt_tac:
            f.write(instr + "\n")
            
    print("================ INTERMEDIATE CODE GENERATION ================")
    print("Unoptimized TAC saved to: tac_unoptimized.txt")
    print("Optimized TAC saved to:   tac_optimized.txt")
    print("==============================================================")
