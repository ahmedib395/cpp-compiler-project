int a = 0;
float b = 5.5 + 4.5; 
int limit = 10;

while (a < limit) {
    a = a + 1;
    if (a == 5) {
        continue;
    }
}
