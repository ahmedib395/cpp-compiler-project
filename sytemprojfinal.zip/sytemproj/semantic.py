import sys
import json

class SemanticError(Exception):
    pass

class SemanticAnalyzer:
    def __init__(self, ast):
        self.ast = ast
        self.symbol_table = {}
        self.loop_depth = 0

    def analyze(self):
        self.visit(self.ast)
        return self.symbol_table

    def visit(self, node):
        if not node: return None
        
        node_type = node.get("type")
        if node_type == "Program":
            for stmt in node.get("body", []):
                self.visit(stmt)
        elif node_type == "Declaration":
            var_id = node.get("id")
            var_type = node.get("var_type")
            line = node.get("line")
            if var_id in self.symbol_table:
                raise SemanticError(f"SEMANTIC ERROR at Line {line}: Variable '{var_id}' is already declared.")
            self.symbol_table[var_id] = var_type
            
            if node.get("value"):
                val_type = self.visit(node.get("value"))
                if val_type and not self.is_compatible(var_type, val_type):
                    raise SemanticError(f"SEMANTIC ERROR at Line {line}: Type mismatch in declaration. Cannot assign {val_type} to {var_type}.")
        elif node_type == "Assignment":
            var_id = node.get("id")
            line = node.get("line")
            if var_id not in self.symbol_table:
                raise SemanticError(f"SEMANTIC ERROR at Line {line}: Variable '{var_id}' used before declaration.")
            var_type = self.symbol_table[var_id]
            val_type = self.visit(node.get("value"))
            if val_type and not self.is_compatible(var_type, val_type):
                raise SemanticError(f"SEMANTIC ERROR at Line {line}: Type mismatch in assignment. Cannot assign {val_type} to {var_type}.")
        elif node_type == "WhileLoop":
            self.visit(node.get("condition"))
            self.loop_depth += 1
            for stmt in node.get("body", []):
                self.visit(stmt)
            self.loop_depth -= 1
        elif node_type == "IfStatement":
            self.visit(node.get("condition"))
            for stmt in node.get("body", []):
                self.visit(stmt)
            if node.get("else_body"):
                for stmt in node.get("else_body"):
                    self.visit(stmt)
        elif node_type == "BreakStatement" or node_type == "ContinueStatement":
            if self.loop_depth == 0:
                stmt_str = "break" if node_type == "BreakStatement" else "continue"
                raise SemanticError(f"SEMANTIC ERROR at Line {node.get('line')}: '{stmt_str}' statement outside of loop.")
        elif node_type == "Condition":
            self.visit(node.get("left"))
            self.visit(node.get("right"))
        elif node_type == "BinaryExpression":
            left_type = self.visit(node.get("left"))
            right_type = self.visit(node.get("right"))
            return self.get_resulting_type(left_type, right_type)
        elif node_type == "Identifier":
            var_id = node.get("value")
            if var_id not in self.symbol_table:
                raise SemanticError(f"SEMANTIC ERROR at Line {node.get('line')}: Variable '{var_id}' used before declaration.")
            return self.symbol_table[var_id]
        elif node_type == "Number":
            val = str(node.get("value"))
            if "." in val:
                return "float"
            return "int"
        else:
            raise SemanticError(f"Unknown node type: {node_type}")

    def is_compatible(self, target_type, value_type):
        if target_type == value_type:
            return True
        if target_type in ("float", "double") and value_type in ("int", "float", "double"):
            return True
        return False

    def get_resulting_type(self, type1, type2):
        if type1 == "double" or type2 == "double":
            return "double"
        if type1 == "float" or type2 == "float":
            return "float"
        return "int"

if __name__ == '__main__':
    input_file = "ast_output.json"
    if len(sys.argv) > 1:
        input_file = sys.argv[1]

    try:
        with open(input_file, 'r') as f:
            ast = json.load(f)
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
        sys.exit(1)

    try:
        analyzer = SemanticAnalyzer(ast)
        symbol_table = analyzer.analyze()
    except SemanticError as e:
        print(str(e))
        sys.exit(1)

    output_file = "symbol_table.json"
    with open(output_file, 'w') as f:
        json.dump(symbol_table, f, indent=4)
        
    print("================== SEMANTIC ANALYZER ==================")
    print(f"Successfully analyzed AST from: {input_file}")
    print(f"Symbol Table saved to: {output_file}")
    print("Symbol Table Content:")
    for var, vtype in symbol_table.items():
        print(f"  {var}: {vtype}")
    print("=======================================================")
