import re
import sys

class LexicalError(Exception):
    pass


TOKEN_TYPES = [
    ('COMMENT', r'//.*|/\*[\s\S]*?\*/'), # Single line or block comment
    ('WHITESPACE', r'\s+'),               # Whitespace matching
    ('NUMBER', r'\b\d+(\.\d+)?\b'),       # Matches integers or floats
    ('KEYWORD', r'\b(int|float|double|if|else|while|break|continue)\b'),
    ('IDENTIFIER', r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'),
    ('OPERATOR', r'==|!=|<=|>=|<|>|=|!|\+|-|\*|/'),
    ('PUNCTUATION', r'[;{}()]'),          # Parentheses and semicolons
    ('LEXICAL_ERROR', r'.')               # Catches any unrecognized character
]

def lex(code):
    """
    Takes the raw string of code and returns a list of tokens.
    Removes WHITESPACE and COMMENT tokens as per requirement.
    """
    tokens = []
    
    # Combine all regex patterns into one large pattern using named groups
    # (?P<NAME>pattern) is the syntax for named groups in Python's re module
    combined_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in TOKEN_TYPES)
    
    # Find all matches in the code
    for match in re.finditer(combined_regex, code):
        kind = match.lastgroup       # The name of the group that matched
        value = match.group()        # The actual string that matched
        
        # Ignored tokens
        if kind in ['WHITESPACE', 'COMMENT']:
            continue
            
        if kind == 'LEXICAL_ERROR':
            line_num = code.count('\n', 0, match.start()) + 1
            col_num = match.start() - code.rfind('\n', 0, match.start())
            # rfind returns -1 if not found, making col_num = match.start() + 1
            error_msg = f"LEXICAL ERROR at Line {line_num}, Column {col_num}: Unrecognized character '{value}'"
            raise LexicalError(error_msg)
        line_num = code.count('\n', 0, match.start()) + 1
        tokens.append((kind, value, line_num))
        
    return tokens

if __name__ == '__main__':
    # Determine the input file (default to test_program.cpp if none provided)
    input_file = "test_program.cpp"
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        
    try:
        with open(input_file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
        print("Please ensure you are providing a valid input file.")
        sys.exit(1)
        
    # Run the Lexical Analyzer and catch any errors
    output_file = "tokens_output.txt"
    try:
        tokens = lex(code)
    except LexicalError as e:
        # If there is an error, write the error message to the output file
        with open(output_file, 'w') as out_f:
            out_f.write(str(e) + "\n")
        print(str(e))
        sys.exit(1)
    
    # Write the successful tokens to the output file
    with open(output_file, 'w') as out_f:
        # Write each token line by line
        for kind, value, line_num in tokens:
            out_f.write(f"<{kind}, {value}, Line: {line_num}>\n")
            
    print("================== LEXICAL ANALYZER ==================")
    print(f"Successfully processed: {input_file}")
    print(f"Total tokens identified: {len(tokens)}")
    print(f"Output saved to: {output_file}")
    print("======================================================")
    
    # Print the tokens in standard format for easy visual check
    for kind, value, line_num in tokens:
        print(f"<{kind}, {value}, Line: {line_num}>")
