import sys
import lexer
import parser
from semantic import SemanticAnalyzer, SemanticError
from icg import TACGenerator, TACOptimizer
import json

def compile_code(input_file):
    try:
        with open(input_file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
        sys.exit(1)

    print(f"Compiling: {input_file}...\n")

    try:
        tokens = lexer.lex(code)
        print("[1/4] Lexical Analysis: PASS")
    except lexer.LexicalError as e:
        print(f"[1/4] Lexical Analysis: FAILED\n{str(e)}")
        sys.exit(1)
        
    with open("tokens_output.txt", "w") as f:
        for kind, value, line_num in tokens:
            f.write(f"<{kind}, {value}, Line: {line_num}>\n")

    try:
        ast = parser.parse(tokens)
        print("[2/4] Syntax Analysis: PASS")
    except parser.SyntaxError as e:
        print(f"[2/4] Syntax Analysis: FAILED\n{str(e)}")
        sys.exit(1)
        
    with open("ast_output.json", "w") as f:
        json.dump(ast, f, indent=4)

    try:
        analyzer = SemanticAnalyzer(ast)
        symbol_table = analyzer.analyze()
        print("[3/4] Semantic Analysis: PASS")
    except SemanticError as e:
        print(f"[3/4] Semantic Analysis: FAILED\n{str(e)}")
        sys.exit(1)
        
    with open("symbol_table.json", "w") as f:
        json.dump(symbol_table, f, indent=4)
        
    try:
        tac_gen = TACGenerator(ast)
        raw_tac = tac_gen.generate()
        
        with open("tac_unoptimized.txt", "w") as f:
            for instr in raw_tac:
                f.write(instr + "\n")
                
        optimizer = TACOptimizer(raw_tac)
        opt_tac = optimizer.optimize()
        
        with open("tac_optimized.txt", "w") as f:
            for instr in opt_tac:
                f.write(instr + "\n")
                
        print("[4/4] Intermediate Code Generation: PASS")
    except Exception as e:
        print(f"[4/4] Intermediate Code Generation: FAILED\n{str(e)}")
        sys.exit(1)
        
    print("\nCompilation completed successfully!")
    print("\n--- OUTPUT FILES GENERATED ---")
    print("1. tokens_output.txt   (Phase 1: Lexical tokens)")
    print("2. ast_output.json     (Phase 2: Abstract Syntax Tree)")
    print("3. symbol_table.json   (Phase 3: Semantic Symbol Table)")
    print("4. tac_unoptimized.txt (Phase 4: Unoptimized TAC)")
    print("5. tac_optimized.txt   (Phase 4: Optimized TAC)")
    
    print("\n--- SYMBOL TABLE PREVIEW ---")
    for var, vtype in symbol_table.items():
        print(f"  {var}: {vtype}")

if __name__ == "__main__":
    input_file = "test_program.cpp"
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
    compile_code(input_file)
