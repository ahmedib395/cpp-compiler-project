import sys
import lexer
import ply.yacc as yacc
import json

class SyntaxErrorExt(Exception):
    pass

# Mock LexToken class required by PLY
class LexToken:
    pass

# Adapter that wraps our list of Phase 1 tokens to look like a PLY lexer
class LexerWrapper:
    def __init__(self, token_list):
        self.raw_tokens = token_list
        self.index = 0
        
    def token(self):
        if self.index >= len(self.raw_tokens):
            return None
        t = self.raw_tokens[self.index]
        self.index += 1
        
        tok = LexToken()
        tok.value = t[1]
        tok.lineno = t[2]
        tok.lexpos = 0 
        
        kind = t[0]
        val = t[1]
        
        if kind == 'KEYWORD':
            tok.type = val.upper() 
        elif kind == 'OPERATOR':
            op_map = {'==':'EQ', '!=':'NEQ', '<=':'LEQ', '>=':'GEQ', 
                      '<':'LT', '>':'GT', '=':'ASSIGN', '!':'NOT', 
                      '+':'PLUS', '-':'MINUS', '*':'TIMES', '/':'DIVIDE'}
            tok.type = op_map[val]
        elif kind == 'PUNCTUATION':
            punc_map = {';':'SEMI', '{':'LBRACE', '}':'RBRACE', '(':'LPAREN', ')':'RPAREN'}
            tok.type = punc_map[val]
        else:
            tok.type = kind
            
        return tok

# List of all explicit tokens for PLY
tokens = (
    'NUMBER', 'IDENTIFIER', 
    'INT', 'FLOAT', 'DOUBLE', 'IF', 'ELSE', 'WHILE', 'BREAK', 'CONTINUE',
    'EQ', 'NEQ', 'LEQ', 'GEQ', 'LT', 'GT', 'ASSIGN',
    'PLUS', 'MINUS', 'TIMES', 'DIVIDE',
    'SEMI', 'LBRACE', 'RBRACE', 'LPAREN', 'RPAREN'
)


# GRAMMAR RULES FOR BOTTOM-UP PARSING (LALR)
# The order here matches our original cfg.txt

def p_program(p):
    '''program : statement_list'''
    p[0] = {"type": "Program", "body": p[1]}

def p_statement_list(p):
    '''statement_list : statement statement_list
                      | empty'''
    if p[1] is None:
        p[0] = []
    else:
        p[0] = [p[1]] + p[2]

def p_statement(p):
    '''statement : declaration
                 | assignment
                 | while_loop
                 | if_statement
                 | break_statement
                 | continue_statement'''
    p[0] = p[1]

def p_declaration(p):
    '''declaration : type IDENTIFIER SEMI
                   | type IDENTIFIER ASSIGN expression SEMI'''
    if len(p) == 4:
        p[0] = {"type": "Declaration", "var_type": p[1], "id": p[2], "value": None, "line": p.lineno(2)}
    else:
        p[0] = {"type": "Declaration", "var_type": p[1], "id": p[2], "value": p[4], "line": p.lineno(2)}

def p_type(p):
    '''type : INT
            | FLOAT
            | DOUBLE'''
    p[0] = p[1]

def p_assignment(p):
    '''assignment : IDENTIFIER ASSIGN expression SEMI'''
    p[0] = {"type": "Assignment", "id": p[1], "value": p[3], "line": p.lineno(1)}

def p_while_loop(p):
    '''while_loop : WHILE LPAREN condition RPAREN LBRACE statement_list RBRACE'''
    p[0] = {"type": "WhileLoop", "condition": p[3], "body": p[6], "line": p.lineno(1)}

def p_if_statement(p):
    '''if_statement : IF LPAREN condition RPAREN LBRACE statement_list RBRACE else_part'''
    p[0] = {"type": "IfStatement", "condition": p[3], "body": p[6], "else_body": p[8], "line": p.lineno(1)}

def p_else_part(p):
    '''else_part : ELSE LBRACE statement_list RBRACE
                 | empty'''
    if p[1] is None:
        p[0] = None
    else:
        p[0] = p[3]

def p_break_statement(p):
    '''break_statement : BREAK SEMI'''
    p[0] = {"type": "BreakStatement", "line": p.lineno(1)}

def p_continue_statement(p):
    '''continue_statement : CONTINUE SEMI'''
    p[0] = {"type": "ContinueStatement", "line": p.lineno(1)}

def p_condition(p):
    '''condition : expression relop expression'''
    p[0] = {"type": "Condition", "left": p[1], "operator": p[2], "right": p[3]}

def p_relop(p):
    '''relop : EQ
             | NEQ
             | LT
             | GT
             | LEQ
             | GEQ'''
    p[0] = p[1]

def p_expression(p):
    '''expression : expression PLUS term
                  | expression MINUS term
                  | term'''
    if len(p) == 4:
        p[0] = {"type": "BinaryExpression", "operator": p[2], "left": p[1], "right": p[3]}
    else:
        p[0] = p[1]

def p_term(p):
    '''term : term TIMES factor
            | term DIVIDE factor
            | factor'''
    if len(p) == 4:
        p[0] = {"type": "BinaryExpression", "operator": p[2], "left": p[1], "right": p[3]}
    else:
        p[0] = p[1]

def p_factor(p):
    '''factor : LPAREN expression RPAREN
              | IDENTIFIER
              | NUMBER'''
    if len(p) == 4:
        p[0] = p[2]
    else:
        if p.slice[1].type == 'IDENTIFIER':
            p[0] = {"type": "Identifier", "value": p[1], "line": p.lineno(1)}
        else:
            p[0] = {"type": "Number", "value": p[1], "line": p.lineno(1)}

def p_empty(p):
    'empty :'
    pass

def p_error(p):
    if p:
        raise SyntaxErrorExt(f"SYNTAX ERROR at Line {p.lineno}: Unexpected token '{p.value}'")
    else:
        raise SyntaxErrorExt("SYNTAX ERROR: Unexpected end of file")

# Build the parser (disable cache file generation)
parser_instance = yacc.yacc(debug=False, write_tables=False)

def parse(token_list):
    wrapper = LexerWrapper(token_list)
    ast = parser_instance.parse(lexer=wrapper)
    return ast

if __name__ == '__main__':
    input_file = "test_program.cpp"
    if len(sys.argv) > 1:
        input_file = sys.argv[1]

    try:
        with open(input_file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
        sys.exit(1)

    try:
        tokens_list = lexer.lex(code)
        ast = parse(tokens_list)
    except Exception as e:
        print(str(e))
        sys.exit(1)

    output_file = "ast_output.json"
    with open(output_file, 'w') as f:
        json.dump(ast, f, indent=4)
        
    print("================== SYNTAX ANALYZER ==================")
    print(f"Successfully LALR parsed: {input_file}")
    print(f"AST saved to: {output_file}")
    print("=====================================================")
